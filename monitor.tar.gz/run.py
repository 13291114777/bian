from realtime_monitor.main import run

if __name__ == "__main__":
    run()
