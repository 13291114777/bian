from __future__ import annotations

import asyncio
import os
from typing import Any, Dict, List, Optional, Tuple

import httpx
from tenacity import retry, stop_after_attempt, wait_random_exponential

BASE_URL = os.getenv("BINANCE_BASE_URL", "https://fapi.binance.com")


class BinanceFuturesClient:
    def __init__(self, *, timeout: float = 15.0, max_connections: int = 50):
        limits = httpx.Limits(max_keepalive_connections=max_connections, max_connections=max_connections)
        self._client = httpx.AsyncClient(base_url=BASE_URL, timeout=timeout, limits=limits)

    async def aclose(self):
        await self._client.aclose()

    @retry(wait=wait_random_exponential(multiplier=0.5, max=5), stop=stop_after_attempt(3))
    async def exchange_info(self) -> Dict[str, Any]:
        r = await self._client.get("/fapi/v1/exchangeInfo")
        r.raise_for_status()
        return r.json()

    @retry(wait=wait_random_exponential(multiplier=0.5, max=5), stop=stop_after_attempt(3))
    async def klines(self, symbol: str, interval: str = "1m", limit: int = 500, startTime: Optional[int] = None, endTime: Optional[int] = None) -> List[List[Any]]:
        params: Dict[str, Any] = {"symbol": symbol.upper(), "interval": interval, "limit": limit}
        if startTime is not None:
            params["startTime"] = startTime
        if endTime is not None:
            params["endTime"] = endTime
        r = await self._client.get("/fapi/v1/klines", params=params)
        r.raise_for_status()
        return r.json()

    @retry(wait=wait_random_exponential(multiplier=0.5, max=5), stop=stop_after_attempt(3))
    async def ticker_price_all(self) -> List[Dict[str, str]]:
        r = await self._client.get("/fapi/v1/ticker/price")
        r.raise_for_status()
        return r.json()


async def fetch_usdt_perp_symbols(client: BinanceFuturesClient) -> List[str]:
    info = await client.exchange_info()
    syms: List[str] = []
    for s in info.get("symbols", []):
        if (
            s.get("quoteAsset") == "USDT"
            and s.get("contractType") == "PERPETUAL"
            and s.get("status") == "TRADING"
        ):
            syms.append(s["symbol"])
    return syms


async def fetch_midnight_close(client: BinanceFuturesClient, symbol: str, midnight_utc_ms: int) -> Optional[float]:
    # 获取本地0点那一根1mK线（openTime == midnight_utc_ms）
    # 若直接limit=1可能拿到下一根，保险起见limit=2并检查openTime。
    kl = await client.klines(symbol, interval="1m", limit=2, startTime=midnight_utc_ms)
    for k in kl:
        # kline: [openTime, open, high, low, close, volume, closeTime, ...]
        if int(k[0]) == midnight_utc_ms:
            return float(k[4])
    # 若未命中，尝试取第一根作为最接近0点后的第一根
    if kl:
        return float(kl[0][4])
    return None


async def fetch_latest_closed_kline(client: BinanceFuturesClient, symbol: str) -> Optional[Tuple[int, float, float, float, float, float]]:
    # 取最近2根，第一根是已收盘的倒数第二根，第二根可能未收盘
    kl = await client.klines(symbol, interval="1m", limit=2)
    if not kl:
        return None
    if len(kl) == 1:
        k = kl[0]
    else:
        k = kl[-2]  # 上一根（已收盘）
    # 返回 (openTime, open, high, low, close, quoteVolume)
    quote_vol = float(k[7]) if len(k) > 7 else 0.0
    return (int(k[0]), float(k[1]), float(k[2]), float(k[3]), float(k[4]), quote_vol)


async def fetch_recent_closes(client: BinanceFuturesClient, symbol: str, limit: int = 600) -> List[Tuple[int, float]]:
    kl = await client.klines(symbol, interval="1m", limit=limit)
    return [(int(k[0]), float(k[4])) for k in kl]
